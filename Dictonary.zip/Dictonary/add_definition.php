<?php
include 'db_connect.php';

if (isset($_POST['word']) && isset($_POST['definition'])) {
    $word = mysqli_real_escape_string($conn, $_POST['word']);
    $definition = mysqli_real_escape_string($conn, $_POST['definition']);

    $check_sql = "SELECT * FROM dictionary WHERE word = '$word'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo "The word '$word' already exists in the dictionary.";
    } else {
        $insert_sql = "INSERT INTO dictionary (word, definition) VALUES ('$word', '$definition')";
        if ($conn->query($insert_sql) === TRUE) {
            echo "Definition for '$word' added successfully.";
        } else {
            echo "Error inserting definition: " . $conn->error;
        }
    }
} else {
    echo "Both word and definition are required.";
}

$conn->close();
?>
