<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dictionary App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Dictionary</h1>
        <div class="search-section">
            <input type="text" id="word" placeholder="Enter a word...">
            <button onclick="searchWord()">Search</button>
        </div>
        <div id="result"></div>
    </div>

    <script>
        function searchWord() {
            var word = document.getElementById('word').value;
            if (word === "") {
                document.getElementById('result').innerHTML = "Please enter a word.";
                return;
            }
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "dictionary.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById('result').innerHTML = xhr.responseText;
                }
            };
            xhr.send("word=" + word);
        }

        function addDefinition(word) {
            var definition = prompt("Add definition for the word: " + word);
            if (definition !== null) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "add_definition.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        document.getElementById('result').innerHTML = xhr.responseText;
                    }
                };
                xhr.send("word=" + word + "&definition=" + definition);
            }
        }
    </script>
</body>
</html>
