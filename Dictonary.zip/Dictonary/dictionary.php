<?php
include 'db_connect.php';

if (isset($_POST['word'])) {
    $word = $_POST['word'];
    
    if (empty($word)) {
        echo "Error: Word is required.";
    } elseif (!ctype_alpha($word)) {
        echo "Error: Only alphabetic characters are allowed. No numbers or special characters.";
        exit;
    } 

    $word = mysqli_real_escape_string($conn, $word);

    $sql = "SELECT definition FROM dictionary WHERE word = '$word'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<strong>Definition:</strong> " . $row['definition'];
    } else {
        echo "Word not found. Please add a definition below.<br>";
        echo "<button onclick=\"addDefinition('$word')\">Add definition for '$word'</button>";
    }
}

$conn->close();
?>
